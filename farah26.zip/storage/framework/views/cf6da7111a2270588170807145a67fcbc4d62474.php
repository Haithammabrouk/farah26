<div class="table-responsive-sm">
    <table class="table table-striped" id="metas-table">
        <thead>
            <tr>
                <th><?php echo app('translator')->get('models/metas.fields.name'); ?></th>
                <th><?php echo app('translator')->get('models/metas.fields.language'); ?></th>
                <th><?php echo app('translator')->get('models/metas.fields.title'); ?></th>
                <th><?php echo app('translator')->get('models/metas.fields.description'); ?></th>
                <th><?php echo app('translator')->get('models/metas.fields.keywords'); ?></th>
                <th colspan="3"><?php echo app('translator')->get('crud.action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $metas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i = 1; ?>
            <?php $__currentLoopData = config('langs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if($i === 1): ?>
                    <?php echo e($meta->id); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($name); ?></td>
                <td><?php echo e($meta->translateOrNew($locale)->title); ?></td>
                <td><?php echo e($meta->translateOrNew($locale)->description); ?></td>
                <td><?php echo e($meta->translateOrNew($locale)->keywords); ?></td>
                <td>
                    <?php if($i === 1): ?>
                    <?php echo Form::open(['route' => ['adminPanel.metas.destroy', $meta->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('metas view')): ?>
                        <a href="<?php echo e(route('adminPanel.metas.show', [$meta->id])); ?>" class='btn btn-ghost-success'><i class="fa fa-eye"></i></a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('metas edit')): ?>
                        <a href="<?php echo e(route('adminPanel.metas.edit', [$meta->id])); ?>" class='btn btn-ghost-info'>
                            <i class="fa fa-edit"></i>
                        </a>
                        <?php endif; ?>
                        
                    </div>
                    <?php echo Form::close(); ?>

                    <?php endif; ?>
                </td>
            </tr>
            <?php $i = 0; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\farah26\resources\views/adminPanel/metas/table.blade.php ENDPATH**/ ?>