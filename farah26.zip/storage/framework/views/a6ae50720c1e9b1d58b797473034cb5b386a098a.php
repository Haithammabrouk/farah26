<!-- Id Field -->

<div class="form-group">
    <?php echo Form::label('id', __('models/reservations.fields.id').':'); ?>

    <p><?php echo e($reservation->id); ?></p>
</div>

<!-- Trip Field -->
<div class="form-group">
    <?php echo Form::label('trip', __('models/reservations.fields.trip').':'); ?>

    <p><?php echo e($reservation->trip->tripCategory->name); ?></p>
</div>

<div class="form-group">
    <label for="">check in</label>
    <p><?php echo e($dates->check_in); ?></p>
</div>

<div class="form-group">
    <label for="">check out</label>
    <p><?php echo e($dates->check_out); ?></p>
</div>

<!-- User Field -->
<div class="form-group">
    <?php echo Form::label('user', __('models/reservations.fields.user').':'); ?>

    <p><?php echo e($reservation->user->first_name .' '. $reservation->user->last_name); ?></p>
</div>

<!-- Price Field -->
<div class="form-group">
    <?php echo Form::label('price', __('models/reservations.fields.price').':'); ?>

    <p><?php echo e($reservation->price); ?></p>
</div>

<!-- Comment Field -->
<div class="form-group">
    <?php echo Form::label('comment', __('models/reservations.fields.comment').':'); ?>

    <p><?php echo e($reservation->comment); ?></p>
</div>

<!-- Status Field -->


<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', __('models/reservations.fields.created_at').':'); ?>

    <p><?php echo e($reservation->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', __('models/reservations.fields.updated_at').':'); ?>

    <p><?php echo e($reservation->updated_at); ?></p>
</div>

<br>
<hr>
<h3>Accommodations</h3>
<hr>

<div class="table-responsive-sm">
    <table class="table table-striped" id="reservations-table">
        <thead>
            <tr>
                <th><?php echo app('translator')->get('models/reservations.fields.type'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.cabin_suite_price'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.accommodation_num'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.guest_name'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.adults_count'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.children_count'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.child1_age'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.child2_age'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.total_price'); ?></th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $reservation->accommodations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accommodation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($accommodation->type == 1 ? 'cabin' : 'suite'); ?></td>
                <td>
                    <?php if($accommodation->type == 1): ?>
                        <?php echo e($accommodation->cabin_price .' / '. $accommodation->single_cabin_price); ?>

                    <?php else: ?>
                        <?php echo e($accommodation->suite_price .' / '. $accommodation->single_suite_price); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($accommodation->accommodation_num); ?></td>
                <td><?php echo e($accommodation->guest_name); ?></td>
                <td><?php echo e($accommodation->adults_count); ?></td>
                <td><?php echo e($accommodation->children_count); ?></td>
                <td>
                    <?php if($accommodation->child1_age): ?>
                        <?php echo e($accommodation->child1_age == 1 ? 'free' : '25%'); ?>

                    <?php else: ?>
                        __
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($accommodation->child2_age): ?>
                        <?php echo e($accommodation->child2_age == 1 ? 'free' : '25%'); ?>

                    <?php else: ?>
                        __
                    <?php endif; ?>
                </td>
                <td><?php echo e($accommodation->total_price); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<br>
<hr>
<h3>Additional Trips</h3>
<hr>

<div class="table-responsive-sm">
    <table class="table table-striped" id="reservations-table">
        <thead>
            <tr>
                <th><?php echo app('translator')->get('models/reservations.fields.trip'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.price'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.adults_count'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.child1_count'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.child2_count'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.total_price'); ?></th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $reservation->reservedAdditionalTrips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aTrip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($aTrip->additionalTrip->name); ?></td>
                <td><?php echo e($aTrip->price); ?></td>
                <td><?php echo e($aTrip->adults_count); ?></td>
                <td><?php echo e($aTrip->child1_count); ?></td>
                <td><?php echo e($aTrip->child2_count); ?></td>
                <td><?php echo e($aTrip->total_price); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH D:\farah26\resources\views/adminPanel/reservations/show_fields.blade.php ENDPATH**/ ?>