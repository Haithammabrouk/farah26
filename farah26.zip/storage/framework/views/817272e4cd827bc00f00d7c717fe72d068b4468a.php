<?php $__env->startSection('content'); ?>
     <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('adminPanel.reservations.index')); ?>"><?php echo app('translator')->get('models/reservations.singular'); ?></a>
            </li>
            <li class="breadcrumb-item active"><?php echo app('translator')->get('crud.detail'); ?></li>
     </ol>
     <div class="container-fluid">
          <div class="animated fadeIn">
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong><?php echo e(__('Whoops! Something went wrong.')); ?></strong>
        <ul class="mb-0 mt-2">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
                 <div class="row">
                     <div class="col-lg-12">
                         <div class="card">
                             <div class="card-header">
                                 <strong><?php echo app('translator')->get('crud.detail'); ?></strong>
                                  <a href="<?php echo e(route('adminPanel.reservations.index')); ?>" class="btn btn-ghost-light">Back</a>
                             </div>
                             <div class="card-body">
                                 <?php echo $__env->make('adminPanel.reservations.show_fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                             </div>
                         </div>
                     </div>
                 </div>
          </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\farah26\resources\views/adminPanel/reservations/show.blade.php ENDPATH**/ ?>