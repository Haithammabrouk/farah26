

<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?php echo route('adminPanel.countries.index'); ?>"><?php echo app('translator')->get('models/countries.singular'); ?></a>
        </li>
        <li class="breadcrumb-item active"><?php echo app('translator')->get('crud.edit'); ?></li>
    </ol>
    <div class="container-fluid">
        <div class="animated fadeIn">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong><?php echo e(__('Whoops! Something went wrong.')); ?></strong>
                    <ul class="mb-0 mt-2">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <i class="fa fa-edit fa-lg"></i>
                            <strong>Edit <?php echo app('translator')->get('models/countries.singular'); ?></strong>
                        </div>
                        <div class="card-body">
                            <?php echo Form::model($coupon, ['route' => ['adminPanel.coupon.update', $coupon->id], 'method' => 'post']); ?>

                            <div class="row">
                                <div class="col nav-tabs-boxed">
                                    <div class="tab-content" id="pills-tabContent" style="padding: 30px;">

                                        <!-- name Field -->
                                        <div class="form-group col-sm-6">
                                            <div class="form-group col-sm-12">
                                                <label for="">coupon code</label>
                                                <input type="text" class="form-control" name="code"
                                                    value="<?php echo e($coupon->coupon_code); ?>" placeholder="Enter coupon code">
                                            </div>
                                            <div class="form-group col-sm-12">
                                                <label for="">coupon duration</label>
                                                <input type="date" class="form-control" name="duration"
                                                    value="<?php echo e($coupon->code_duration); ?>"
                                                    placeholder="Enter coupon duration">
                                            </div>
                                            <!-- Closed Cabin Field -->
                                            <div class="form-group col-sm-12">
                                                <label for="">Trips</label><br>
                                                <?php if($coupon->related_trips->count() == $trips->count()): ?>
                                                    <input type="checkbox" id="music" name="all_trips" value="all_trips"
                                                        checked /><label style="margin-left: 10px;" for="music">all
                                                        trips</label>
                                                    <select name="trips[]" class="form-control select2" multiple="multiple">
                                                        <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additionalTrip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($additionalTrip->id); ?>"
                                                                <?php echo e(isset($tripsAdditionals) && in_array($additionalTrip->id, $tripsAdditionals) ? 'selected' : ''); ?>>
                                                                <?php echo e($additionalTrip->id); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php else: ?>
                                                    <input type="checkbox" id="music" name="all_trips"
                                                        value="all_trips" /><label style="margin-left: 10px;"
                                                        for="music">all
                                                        trips</label>

                                                    <select name="trips[]" class="form-control select2" multiple="multiple">
                                                        <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additionalTrip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($additionalTrip->id); ?>"
                                                                <?php echo e(isset($tripsAdditionals) && in_array($additionalTrip->id, $tripsAdditionals) ? 'selected' : ''); ?>>
                                                                <?php echo e($additionalTrip->id); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                <?php endif; ?>


                                            </div>
                                            <div class="form-group col-sm-12">
                                                <label for="">discount</label>
                                                <input type="number" class="form-control" name="discount"
                                                    value="<?php echo e($coupon->discount); ?>" placeholder="Enter discount">
                                            </div>
                                            <div class="form-group col-sm-12">
                                                <label for="">usage limit</label>
                                                <input type="number" class="form-control" name="limit"
                                                    value="<?php echo e($coupon->usage_limit); ?>" placeholder="Enter usage limit">
                                            </div>
                                            <div class="form-group col-sm-12">
                                                <label for="">active</label>
                                                <select name="activation" class="form-control">
                                                    <option>Select Activation</option>
                                                    <option value="1">Active</option>
                                                    <option value="0">Inactive</option>
                                                </select>
                                            </div>
                                            <!-- Submit Field -->
                                            <div class="form-group col-sm-12">
                                                <?php echo Form::submit(__('crud.save'), ['class' => 'btn btn-primary']); ?>

                                                <a href="<?php echo e(route('adminPanel.coupon')); ?>"
                                                    class="btn btn-default"><?php echo app('translator')->get('crud.cancel'); ?></a>
                                            </div>
                                        </div>
                                    </div>



                                </div>
                            </div>

                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

</div>

<?php echo $__env->make('adminPanel.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\farah26\resources\views/adminPanel/coupons/edit_fields.blade.php ENDPATH**/ ?>