<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/admins*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.admins.index')); ?>">
        <i class="nav-icon icon-user"></i>
        <span><?php echo app('translator')->get('models/admins.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/roles*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.roles.index')); ?>">
        <i class="nav-icon icon-check "></i>
        <span><?php echo app('translator')->get('models/roles.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('metas view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/metas*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.metas.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/metas.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<li class="nav-item <?php echo e(Request::is('adminPanel/reports*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.reports.index')); ?>">
        <i class="nav-icon fas fa-chart-bar"></i>
        <span>Reports</span>
    </a>
</li>

<li class="nav-item <?php echo e(Request::is('adminPanel/settings*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.settings.index')); ?>">
        <i class="nav-icon fas fa-cog"></i>
        <span>Settings</span>
    </a>
</li>

<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('adminPanel.coupon')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span>Coupons</span>
    </a>
</li>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('countries view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/countries*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.countries.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/countries.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/users*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.users.index')); ?>">
        <i class="nav-icon icon-user"></i>
        <span><?php echo app('translator')->get('models/users.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pages view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/pages*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.pages.index')); ?>">
        <i class="nav-icon icon-docs"></i>
        <span><?php echo app('translator')->get('models/pages.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tripCategories view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/tripCategories*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.tripCategories.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/tripCategories.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('trips view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/trips*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.trips.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/trips.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reservations view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/reservations*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.reservations.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/reservations.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('additionalTrips view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/additionalTrips*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.additionalTrips.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/additionalTrips.plural'); ?></span>
    </a>
</li>
<?php endif; ?>


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('additionalTripsPhotos view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/additionalTripsPhotos*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.additionalTripsPhotos.index')); ?>" style="width: 300px;">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/additionalTripsPhotos.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('galleries view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/galleries*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.galleries.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/galleries.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('galleryPhotos view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/galleryPhotos*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.galleryPhotos.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/galleryPhotos.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contactuses view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/contactuses*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.contactuses.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/contactuses.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('facilities view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/facilities*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.facilities.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/facilities.plural'); ?></span>
    </a>
</li>
<?php endif; ?>



<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('infos view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/infos*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.infos.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/infos.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('itineraries view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/itineraries*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.itineraries.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/itineraries.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('itineraryDetails view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/itineraryDetails*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.itineraryDetails.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/itineraryDetails.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('newsletters view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/newsletters*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.newsletters.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/newsletters.plural'); ?></span>
    </a>
</li>
<?php endif; ?>



<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('decks view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/decks*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.decks.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/decks.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('partners view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/partners*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.partners.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/partners.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('uniques view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/uniques*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.uniques.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/uniques.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tripadvisors view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/tripadvisors*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.tripadvisors.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/tripadvisors.plural'); ?></span>
    </a>
</li>
<?php endif; ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sliderPhotos view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/sliderPhotos*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.sliderPhotos.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/sliderPhotos.plural'); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('closedDates view')): ?>
<li class="nav-item <?php echo e(Request::is('adminPanel/closedDates*') ? 'active' : ''); ?>">
    <a class="nav-link" href="<?php echo e(route('adminPanel.closedDates.index')); ?>">
        <i class="nav-icon icon-cursor"></i>
        <span><?php echo app('translator')->get('models/closedDates.plural'); ?></span>
    </a>
</li>
<?php endif; ?>
<?php /**PATH D:\farah26\resources\views/adminPanel/layouts/menu.blade.php ENDPATH**/ ?>