<div class="table-responsive-sm">
    <table class="table table-striped " id="admins-table">
        <thead>
            <th><?php echo app('translator')->get('models/admins.fields.id'); ?></th>
            <th><?php echo app('translator')->get('models/admins.fields.name'); ?></th>
        <th><?php echo app('translator')->get('models/admins.fields.email'); ?></th>
        <th><?php echo app('translator')->get('models/admins.fields.status'); ?></th>
            <th colspan="3"><?php echo app('translator')->get('crud.action'); ?></th>
        </thead>
        <thead style="background: #2f353a;">
            <?php echo Form::open(['route' => ['adminPanel.admins.index'], 'method' => 'GET']); ?>


            <th>

            </th>
            <th>
                <?php echo Form::text('name', request()->filled('name')? old('name', request('name')) : null, ['class' => 'form-control', 'placeholder' => 'Name']); ?>

            </th>
            <th>
                <?php echo Form::email('email', request()->filled('email')? old('email', request('email')) : null, ['class' => 'form-control', 'placeholder' => 'Email']); ?>

            </th>
            <th>
                <?php echo Form::select('status', ['0' => 'Inactive', '1' => 'Active'], request()->filled('status')? old('status', request('status')) : null, ['class' => 'form-control', 'placeholder' => 'Status...']); ?>

            </th>
            <th>
                <div class='btn-group'>
                    <?php echo Form::button('<i class="fa fa-search"></i>', ['type' => 'submit', 'class' => 'btn btn-ghost-light', 'data-placement' => "top", 'data-html' => "true", 'data-original-title' => "All Ads in vape masr"]); ?>

                    <a href="<?php echo e(route('adminPanel.admins.index')); ?>" class="btn btn-ghost-light" , data-placement ="top" data-html = "true"data-original-title ="All Ads in vape masr"><i class="fa fa-ban"></i></a>
                </div>
            </th>

            <?php echo Form::close(); ?>

        </thead>
        <tbody>

        <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($admin->id); ?></td>
                <td><?php echo e($admin->name); ?></td>
                <td><?php echo e($admin->email); ?></td>
                <td><?php echo e($admin->status ? 'Active' : 'Inactive'); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['adminPanel.admins.destroy', $admin->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('adminPanel.admins.show', [$admin->id])); ?>" class='btn btn-ghost-success'><i class="fa fa-eye"></i></a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins edit')): ?>
                        <a href="<?php echo e(route('adminPanel.admins.edit', [$admin->id])); ?>" class='btn btn-ghost-info'><i class="fa fa-edit"></i></a>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins destroy')): ?>
                        <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-ghost-danger', 'onclick' => 'return confirm("'.__('crud.are_you_sure').'")']); ?>

                        <?php endif; ?>
                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\farah26\resources\views/adminPanel/admins/table.blade.php ENDPATH**/ ?>