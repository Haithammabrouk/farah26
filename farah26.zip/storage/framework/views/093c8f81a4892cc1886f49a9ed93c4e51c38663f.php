<div class="table-responsive-sm">
    <table class="table table-striped table-bordered" id="reservations-table">
        <thead>
            <tr>
                <th><?php echo app('translator')->get('models/reservations.fields.id'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.trip'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.user'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.price'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.status'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.ip_address'); ?></th>
                <th><?php echo app('translator')->get('models/reservations.fields.created_at'); ?></th>
                <th colspan="3"><?php echo app('translator')->get('crud.action'); ?></th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($reservation->uuid); ?>

                </td>
                <td>
                    <a href="<?php echo e(route('adminPanel.trips.show', $reservation->trip_id)); ?>">
                        <?php echo e($reservation->trip->tripCategory->name); ?>

                    </a>
                </td>
                <td>
                    <a href="<?php echo e(route('adminPanel.users.show', $reservation->user_id)); ?>">
                        <?php echo e($reservation->user->first_name .' '. $reservation->user->last_name); ?>

                    </a>
                </td>
                <td><?php echo e($reservation->price); ?></td>
                <td>
                    <?php if($reservation->status === 1): ?>
                        <?php echo app('translator')->get('models/reservations.fields.success'); ?>
                    <?php elseif($reservation->status === 0): ?>
                        <?php echo app('translator')->get('models/reservations.fields.failed'); ?>
                    <?php else: ?>
                        <?php echo app('translator')->get('models/reservations.fields.pending'); ?>
                    <?php endif; ?>
                </td>
                <td><?php echo e($reservation->ip_address); ?></td>
                <td><?php echo e($reservation->created_at); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['adminPanel.reservations.destroy', $reservation->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('adminPanel.reservations.show', [$reservation->id])); ?>" class='btn btn-ghost-success'><i class="fa fa-eye"></i></a>
                        
                    </div>
                    <?php echo Form::close(); ?>

                    <?php if($reservation->status === 0): ?>
                        <div class='btn-group'>
                            <!--<?php echo e($reservation->id); ?>-->
                            <!--deletereservations-->
                            <a href="<?php echo e(route('deletereservations' ,$reservation->id )); ?>" class='btn btn-ghost-danger'><i class="fa fa-trash-o"></i></a>
                        </div>
                    <?php endif; ?>
                    
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH D:\farah26\resources\views/adminPanel/reservations/table.blade.php ENDPATH**/ ?>