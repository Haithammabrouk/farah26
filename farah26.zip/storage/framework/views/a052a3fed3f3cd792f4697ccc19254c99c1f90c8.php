<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><?php echo app('translator')->get('models/reservations.plural'); ?></li>
    </ol>
    <div class="container-fluid">
        <div class="animated fadeIn">
             <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <div class="row">
                 <div class="col-lg-12">
                     <div class="card">
                         <div class="card-header">
                             <i class="fa fa-align-justify"></i>
                             <?php echo app('translator')->get('models/reservations.plural'); ?>
                             
                         </div>
                         <div class="card-body">
                             <!-- Search Form -->
                             <div class="row mb-3">
                                 <div class="col-md-6">
                                     <form method="GET" action="<?php echo e(route('adminPanel.reservations.index')); ?>" class="form-inline">
                                         <div class="input-group w-100">
                                             <input type="text"
                                                    name="search"
                                                    class="form-control"
                                                    placeholder="Search by name, email, mobile..."
                                                    value="<?php echo e($search ?? ''); ?>">
                                             <div class="input-group-append">
                                                 <button class="btn btn-primary" type="submit">
                                                     <i class="fa fa-search"></i> Search
                                                 </button>
                                                 <?php if($search ?? false): ?>
                                                 <a href="<?php echo e(route('adminPanel.reservations.index')); ?>" class="btn btn-secondary">
                                                     <i class="fa fa-times"></i> Clear
                                                 </a>
                                                 <?php endif; ?>
                                             </div>
                                         </div>
                                     </form>
                                 </div>
                             </div>

                             <?php echo $__env->make('adminPanel.reservations.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="d-flex justify-content-center mt-3">
     <?php echo e($reservations->appends(['search' => $search ?? ''])->links('pagination::bootstrap-4')); ?>

</div>
                         </div>
                     </div>
                  </div>
             </div>
         </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminPanel.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\farah26\resources\views/adminPanel/reservations/index.blade.php ENDPATH**/ ?>