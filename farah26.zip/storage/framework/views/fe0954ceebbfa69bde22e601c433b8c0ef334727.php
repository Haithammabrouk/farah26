<div class="table-responsive-sm">
    <table class="table table-striped" id="countries-table">
        <thead>
            <tr>
                <th>coupon code</th>
                <th>coupon duration</th>
                <th>discount</th>
                <th>usage limit</th>
                <th>trips</th>
                <th>active</th>
                <th colspan="3"><?php echo app('translator')->get('crud.action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($coupon->coupon_code); ?></td>
                    <td><?php echo e($coupon->code_duration); ?></td>
                    <td><?php echo e($coupon->discount); ?></td>
                    <td><?php echo e($coupon->usage_limit); ?></td>
                    <td>
                        <div class="container">
                            <div class="row">
                                <?php $__currentLoopData = $coupon->related_trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-1">
                                        <span class="badge badge-secondary"><?php echo e($value->trip_id); ?></span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <?php if($coupon->active == 1): ?>
                            <p class="btn btn-success">Active</p>
                        <?php else: ?>
                            <p class="btn btn-danger">Inctive</p>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class='btn-group'>
                            <a href="<?php echo e(route('adminPanel.coupon.edit', [$coupon->id])); ?>" class='btn btn-ghost-info'><i class="fa fa-edit"></i></a>

                            <?php echo Form::open(['route' => ['adminPanel.coupon.destroy', $coupon->id], 'method' => 'post']); ?>

                            <?php echo Form::button('<i class="fa fa-trash"></i>', [
                                'type' => 'submit',
                                'class' => 'btn btn-ghost-danger',
                                'onclick' => 'return confirm("' . __('crud.are_you_sure') . '")',
                            ]); ?>

                            <?php echo Form::close(); ?>

                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\farah26\resources\views/adminPanel/coupons/table.blade.php ENDPATH**/ ?>