<div class="table-responsive-sm">
    <table class="table table-striped" id="pages-table">
        <thead>
            <th><?php echo app('translator')->get('models/pages.fields.id'); ?></th>
            <th><?php echo app('translator')->get('models/pages.fields.language'); ?></th>
            <th><?php echo app('translator')->get('models/pages.fields.name'); ?></th>
            <th colspan="3"><?php echo app('translator')->get('crud.action'); ?></th>
        </thead>
        <thead style="background: #2f353a;">
            <?php echo Form::open(['route' => ['adminPanel.pages.index'], 'method' => 'GET']); ?>


            <th>
                <?php echo Form::text('id', request()->filled('id')? old('id', request('id')) : null, ['class' => 'form-control', 'placeholder' => 'Search by ID']); ?>

            </th>
            <th>

            </th>
            <th>
                <?php echo Form::text('name', request()->filled('name')? old('name', request('name')) : null, ['class' => 'form-control', 'placeholder' => 'Search by Name']); ?>

            </th>
            <th>
                <div class='btn-group'>
                    <?php echo Form::button('<i class="fa fa-search"></i>', ['type' => 'submit', 'class' => 'btn btn-ghost-light']); ?>

                    <a href="<?php echo e(route('adminPanel.pages.index')); ?>" class="btn btn-ghost-light"><i class="fa fa-ban"></i></a>
                </div>
            </th>

            <?php echo Form::close(); ?>

        </thead>
        <tbody>
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $i = 1; ?>
            <?php $__currentLoopData = config('langs'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if($i == 1): ?>
                    <?php echo e($page->id); ?>

                    <?php endif; ?>
                </td>
                <td><?php echo e($name); ?></td>
                <td><?php echo e($page->translateOrNew($locale)->name); ?></td>
                <td>
                    <?php if($i == 1): ?>
                    <?php echo Form::open(['route' => ['adminPanel.pages.destroy', $page->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pages view')): ?>
                        <a href="<?php echo e(route('adminPanel.pages.show', [$page->id])); ?>" class='btn btn-ghost-success'>
                            <i class="fa fa-eye"></i>
                        </a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pages edit')): ?>
                        <a href="<?php echo e(route('adminPanel.pages.edit', [$page->id])); ?>" class='btn btn-ghost-info'>
                            <i class="fa fa-edit"></i>
                        </a>
                        <?php endif; ?>
                        
                    </div>
                    <?php echo Form::close(); ?>

                    <?php endif; ?>
                </td>
            </tr>
            <?php $i = 0; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH D:\farah26\resources\views/adminPanel/pages/table.blade.php ENDPATH**/ ?>