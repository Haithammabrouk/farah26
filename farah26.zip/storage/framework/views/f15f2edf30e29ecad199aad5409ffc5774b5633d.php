

<?php $__env->startSection('content'); ?>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><?php echo app('translator')->get('models/pages.plural'); ?></li>
    </ol>
    <div class="container-fluid">
        <div class="animated fadeIn">
             <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <div class="row">
                 <div class="col-lg-12">
                     <div class="card">
                         <div class="card-header">
                             <i class="fa fa-align-justify"></i>
                             <?php echo app('translator')->get('models/pages.plural'); ?>
                             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pages create')): ?>
                                
                             <?php endif; ?>
                            </div>
                         <div class="card-body">
                             <?php echo $__env->make('adminPanel.pages.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            

                              <div class="d-flex justify-content-center mt-3">
                                <?php echo e($pages->links('pagination::bootstrap-4')); ?>

                            </div>
                         </div>
                     </div>
                  </div>
             </div>
         </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminPanel.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\farah26\resources\views/adminPanel/pages/index.blade.php ENDPATH**/ ?>