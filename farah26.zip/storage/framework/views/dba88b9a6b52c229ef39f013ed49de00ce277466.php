<div class="form-group">
    <label for="<?php echo e($setting->key); ?>" class="font-weight-bold">
        <?php echo e($setting->label); ?>

        <?php if($setting->description): ?>
            <i class="fas fa-info-circle text-muted ml-1"
               data-toggle="tooltip"
               title="<?php echo e($setting->description); ?>"></i>
        <?php endif; ?>
    </label>

    <?php if($setting->type === 'textarea'): ?>
        <textarea
            name="<?php echo e($setting->key); ?>"
            id="<?php echo e($setting->key); ?>"
            class="form-control"
            rows="4"
            placeholder="<?php echo e($setting->description ?? $setting->label); ?>"
        ><?php echo e(old($setting->key, $setting->value)); ?></textarea>

    <?php elseif($setting->type === 'boolean'): ?>
        <div class="custom-control custom-switch">
            <input
                type="checkbox"
                class="custom-control-input"
                id="<?php echo e($setting->key); ?>"
                name="<?php echo e($setting->key); ?>"
                value="1"
                <?php echo e(old($setting->key, $setting->value) == '1' ? 'checked' : ''); ?>

            >
            <label class="custom-control-label" for="<?php echo e($setting->key); ?>">
                <?php echo e($setting->description ?? 'Enable this option'); ?>

            </label>
        </div>

    <?php elseif($setting->type === 'number'): ?>
        <input
            type="number"
            name="<?php echo e($setting->key); ?>"
            id="<?php echo e($setting->key); ?>"
            class="form-control"
            value="<?php echo e(old($setting->key, $setting->value)); ?>"
            placeholder="<?php echo e($setting->description ?? $setting->label); ?>"
        >

    <?php else: ?>
        
        <input
            type="text"
            name="<?php echo e($setting->key); ?>"
            id="<?php echo e($setting->key); ?>"
            class="form-control"
            value="<?php echo e(old($setting->key, $setting->value)); ?>"
            placeholder="<?php echo e($setting->description ?? $setting->label); ?>"
        >
    <?php endif; ?>

    <?php if($setting->description && $setting->type !== 'boolean'): ?>
        <small class="form-text text-muted">
            <?php echo e($setting->description); ?>

        </small>
    <?php endif; ?>
</div>
<?php /**PATH D:\farah26\resources\views/adminPanel/settings/partials/field.blade.php ENDPATH**/ ?>