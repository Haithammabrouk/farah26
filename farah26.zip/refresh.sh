#!/bin/bash

php artisan migrate:refresh
