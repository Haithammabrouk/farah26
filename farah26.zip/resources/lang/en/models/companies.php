<?php

return array (
  'singular' => 'Company',
  'plural' => 'Companies',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'url' => 'Url',
    'about' => 'About',
    'logo' => 'Logo',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
