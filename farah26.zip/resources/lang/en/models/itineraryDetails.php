<?php

return array (
  'singular' => 'Itinerary Detail',
  'plural' => 'Itinerary Details',
  'fields' => 
  array (
    'id' => 'Id',
    'itinerary_id' => 'Itinerary',
    'text' => 'Text',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
