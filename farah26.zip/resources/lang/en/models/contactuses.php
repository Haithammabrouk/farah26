<?php

return array (
  'singular' => 'Contact Us',
  'plural' => 'Contact Us',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'email' => 'Email',
    'mobile' => 'Mobile',
    'message' => 'Message',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
