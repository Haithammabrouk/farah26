<?php

return array (
  'singular' => 'Itinerary',
  'plural' => 'Itineraries',
  'fields' => 
  array (
    'id' => 'Id',
    'trip_category_id' => 'Trip Category',
    'day' => 'Day',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
