<?php

return array (
  'singular' => 'Newsletter',
  'plural' => 'Newsletters',
  'fields' => 
  array (
    'id' => 'Id',
    'email' => 'Email',
  ),
);
