<?php

return array(
  'singular' => 'Page',
  'plural' => 'Pages',
  'fields' =>
  array(
    'id' => 'Id',
    'language' => 'Language',
     'linke' => 'Linke',
    'active' => 'Active',
    'in_navbar' => 'In Navbar',
    'in_footer' => 'In Footer',
    'photo' => 'File',
    'name' => 'Name',
    'content' => 'Content',
    'slug' => 'URL',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
