<?php

return array(
  'singular' => 'Unique',
  'plural' => 'Uniques',
  'fields' =>
  array(
    'id' => 'Id',
    'title' => 'Title',
    'text' => 'Text',
    'photo' => 'Photo',
    'lang' => 'Langauge',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
