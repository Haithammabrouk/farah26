<?php

return array (
  'singular' => 'SinglePrice',
  'plural' => 'SinglePrices',
  'fields' => 
  array (
    'SinglePrice' => 'Singleprice',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
