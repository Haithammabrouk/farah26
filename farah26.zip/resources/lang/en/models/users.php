<?php

return array (
  'singular' => 'User',
  'plural' => 'Users',
  'fields' =>
  array (
    'id' => 'Id',
    'email' => 'Email',
    'name' => 'Name',
    'mobile' => 'Mobile',
    'country' => 'Country',
    'created_at' => 'Registered At',
  ),
);
