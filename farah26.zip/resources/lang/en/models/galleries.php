<?php

return array(
  'singular' => 'Gallery',
  'plural' => 'Galleries',
  'fields' =>
  array(
    'id' => 'Id',
    'status' => 'Status',
    'name' => "Name",
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
