<?php

return array(
  'singular' => 'Additional Trips Photos',
  'plural' => 'Additional Trips Photos',
  'fields' =>
  array(
    'id' => 'Id',
    'photo' => 'Photo',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
    'trip_name' => 'Trip Name',
  ),
);
