<?php

return array(
  'singular' => 'Gallery Photo',
  'plural' => 'Gallery Photos',
  'fields' =>
  array(
    'id' => 'Id',
    'gallery_id' => 'Gallery',
    'is_home' => 'Is Home',
    'photo' => 'Photo',
    'url' => 'Youtube Link',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
