<?php

return array(
  'singular' => 'Deck',
  'plural' => 'Decks',
  'fields' =>
  array(
    'id' => 'Id',
    'file' => 'Photo 1',
    'other_file' => 'Photo 2',
    'title' => "Title",
    'content' => "Content",
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
