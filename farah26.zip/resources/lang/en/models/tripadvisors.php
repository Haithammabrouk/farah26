<?php

return array(
  'singular' => 'Trip Advisor',
  'plural' => 'Trip Advisors',
  'fields' =>
  array(
    'id' => 'Id',
    'author' => 'Author',
    'title' => 'Title',
    'text' => 'Text',
    'url' => 'URL',
    'lang' => 'Language',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
