<?php

return array(
  'singular' => 'Partner',
  'plural' => 'Partners',
  'fields' =>
  array(
    'id' => 'Id',
    'photo' => 'Photo',
    'url' => 'Url',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
