<?php

return array (
  'singular' => 'Opened Date',
  'plural' => 'Opened Dates',
  'fields' => 
  array (
    'id' => 'Id',
    'date' => 'Date',
  ),
);
