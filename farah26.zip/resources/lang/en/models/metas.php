<?php

return array(
  'singular' => 'SEO',
  'plural' => 'SEOs',
  'fields' =>
  array(
    'id' => 'Id',
    'name' => 'Name',
    'title' => 'Title',
    'description' => 'Description',
    'keywords' => 'Keywords',
    'language' => 'Language',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
