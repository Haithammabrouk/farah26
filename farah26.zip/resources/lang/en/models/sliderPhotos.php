<?php

return array(
  'singular' => 'Slider Photo',
  'plural' => 'Slider Photos',
  'fields' =>
  array(
    'id' => 'Id',
    'photo' => 'Photo',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
