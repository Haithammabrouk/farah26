<?php

return array(
  'singular' => 'Facility Photo',
  'plural' => 'Facility Photos',
  'fields' =>
  array(
    'id' => 'Id',
    'photo' => 'Photo',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
    'facility_title' => 'Facility Title'
  ),
);
