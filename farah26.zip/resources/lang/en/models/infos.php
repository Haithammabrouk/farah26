<?php

return array (
  'singular' => 'Info',
  'plural' => 'Infos',
  'fields' => 
  array (
    'id' => 'Id',
    'key' => 'Key',
    'value' => 'Value',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
