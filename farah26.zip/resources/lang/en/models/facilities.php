<?php

return array(
  'singular' => 'Facility',
  'plural' => 'Facilities',
  'fields' =>
  array(
    'id' => 'Id',
    'img' => 'Image',
    'name' => 'Name',
    'lang' => 'Language',
    'details' => 'Details',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
