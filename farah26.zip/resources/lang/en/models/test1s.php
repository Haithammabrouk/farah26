<?php

return array (
  'singular' => 'test1',
  'plural' => 'test1s',
  'fields' => 
  array (
    'test' => 'Test',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
