<?php

return array (
  'singular' => 'Reserved Additional Trip',
  'plural' => 'Reserved Additional Trips',
  'fields' => 
  array (
    'id' => 'Id',
    'reservation_id' => 'Reservation',
    'additional_trip_id' => 'Additional Trip',
    'price' => 'Price',
    'adults_count' => 'Adults Count',
    'child1_count' => 'Child1 Count',
    'child2_count' => 'Child2 Count',
    'total_price' => 'Total Price',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
