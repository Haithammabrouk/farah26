<?php

return array(
  'singular' => 'Additional Trip',
  'plural' => 'Additional Trips',
  'fields' =>
  array(
    'id' => 'Id',
    'trip_category_id' => 'Trip Category',
    'price' => 'Price',
    'SinglePrice' => 'SinglePrice',
    'img' => 'Image',
    'name' => 'Name',
    'lang' => 'Language',
    'location' => 'Location',
    'details' => 'Details',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
