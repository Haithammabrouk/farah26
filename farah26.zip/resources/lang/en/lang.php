<?php

return [

    'wrongCredential' => 'wrong email or password',
    'accountNotActive' => 'account not active',
    'wrongOldPassword' => 'old password not correct',
    'wrongPassword' => 'password not correct',
    'logoutMsg' => 'Successfully logged out',


];
