<?php

return  [
    'chooseCompany' => 'Choose Company',
    'chooseCountry' => 'Choose Country',
    'choosePage' => 'Choose Page',
    'viewSpecs' => 'View Specs'
];
