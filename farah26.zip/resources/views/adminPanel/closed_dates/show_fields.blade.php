<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', __('models/closedDates.fields.id').':') !!}
    <p>{{ $closedDates->id }}</p>
</div>

<!-- Date Field -->
<div class="form-group">
    {!! Form::label('date', __('models/closedDates.fields.date').':') !!}
    <p>{{ $closedDates->date }}</p>
</div>

