<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            @include('adminPanel.layouts.menu')
        </ul>
    </nav>
    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div>
